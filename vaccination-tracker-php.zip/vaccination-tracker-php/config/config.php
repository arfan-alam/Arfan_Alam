<?php
// App configuration
define('APP_NAME', 'Vaccination Tracker');
define('BASE_URL', ''); // leave empty if hosting at web root
?>
